#include <iostream>
#include <vector>
#include <list>
#include <unordered_map> // Para a implementação do DHT
#include <string>

using namespace std;

// Estrutura para armazenar as entradas na DHT
struct DHTEntry {
    string chave;
    string valor;
    // Outros atributos conforme necessário

    DHTEntry(string _chave, string _valor) : chave(_chave), valor(_valor) {}
};

// Implementação da Distributed Hash Table (DHT)
class DHT {
private:
    static const int num_buckets = 10;
    vector<unordered_map<string, string>> buckets;

public:
    DHT() {
        buckets.resize(num_buckets);
    }

    // Função hash para mapear uma chave para um índice no bucket
    int hashFunction(const string& chave) {
        hash<string> hash_fn;
        return hash_fn(chave) % num_buckets;
    }

    // Método para inserir uma entrada na DHT
    void inserir(const string& chave, const string& valor) {
        int indice = hashFunction(chave);
        buckets[indice][chave] = valor;
    }

    // Método para buscar uma entrada na DHT pelo seu chave
    string buscar(const string& chave) {
        int indice = hashFunction(chave);
        if (buckets[indice].count(chave)) {
            return buckets[indice][chave];
        } else {
            return "Chave não encontrada na DHT"; // Chave não encontrada
        }
    }

    // Método para remover uma entrada na DHT pelo seu chave
    void remover(const string& chave) {
        int indice = hashFunction(chave);
        if (buckets[indice].count(chave)) {
            buckets[indice].erase(chave);
        }
    }
};

// Função para exibir as entradas na DHT
void exibirEntrada(const DHTEntry& entrada) {
    cout << "Chave: " << entrada.chave << ", Valor: " << entrada.valor << endl;
}

int main() {
    DHT dht;

    // Casos de teste
    dht.inserir("chave1", "valor1");
    dht.inserir("chave2", "valor2");

    cout << "Resultado da busca pela chave1: " << dht.buscar("chave1") << endl;
    cout << "Resultado da busca pela chave2: " << dht.buscar("chave2") << endl;
    cout << "Resultado da busca pela chave3: " << dht.buscar("chave3") << endl;

    dht.remover("chave1");
    cout << "Resultado da busca pela chave1 após remoção: " << dht.buscar("chave1") << endl;

    return 0;
}
