# Projeto de Distributed Hash Table (DHT) em C++

Este projeto implementa uma Distributed Hash Table básica em C++ para armazenar registros de mercadorias.

## Instruções

1. Clone o repositório para o seu ambiente de desenvolvimento.
2. Abra o arquivo principal do projeto em um compilador C++.
3. Compile e execute o código para testar a DHT.

## Casos de Teste

1. **Inserção e Busca**: inserir uma entrada na DHT e verificar se ela pode ser encontrada.
2. **Remoção de Entrada**: remover uma entrada da DHT e garantir que ela não possa ser encontrada.
3. **Busca por Chave Inexistente**: tentar buscar uma chave que não existe na DHT e verificar o resultado.
4. **Inserção de Múltiplas Entradas**: inserir várias entradas na DHT e verificar se todas podem ser encontradas corretamente.
5. **Tratamento de Colisões**: verificar o tratamento de colisões ao inserir várias entradas com chaves que colidem.

## Resultados dos Testes

### Caso de Teste 1: Inserção e Busca

- **Resultado**: Passou
- **Evidência**: ![Captura de tela da saída do teste](https://raw.githubusercontent.com/LucasG99/PonderadaProg/main/resultado.png)

### Caso de Teste 2: Remoção de Entrada

- **Resultado**: Passou
- **Evidência**: ![Captura de tela da saída do teste](https://raw.githubusercontent.com/LucasG99/PonderadaProg/main/resultado.png)

# Projeto de Implementação de Mapping em Solidity

Este projeto inclui uma implementação de um contrato de mapeamento simples em Solidity para armazenar pares chave-valor.

## Contrato em Solidity

O contrato MappingContract permite definir, obter e remover valores associados a chaves inteiras.

## Resultados dos Testes

### Caso de Teste 1: Inserção e Busca

- **Resultado**: Passou
- **Descrição**: Inseri duas entradas na DHT para verificar se elas podem ser encontradas corretamente.
- **Evidência**: ![Captura de tela da saída do teste](caminho/para/captura-de-tela-1.png)

### Caso de Teste 2: Remoção de Entrada

- **Resultado**: Passou
- **Descrição**: Removi uma entrada da DHT para verificar se ela não pôde ser encontrada.
- **Evidência**: ![Captura de tela da saída do teste](https://raw.githubusercontent.com/LucasG99/PonderadaProg/main/resultado.png) Obs: os resultados foram iguais aos da  aplicação em C++.

### Caso de Teste 3: Busca por Chave Inexistente

- **Resultado**: Passou
- **Descrição**: Tentei buscar uma chave que não existe na DHT e verifiquei se o resultado foi conforme o esperado.
- **Evidência**: ![Captura de tela da saída do teste](https://raw.githubusercontent.com/LucasG99/PonderadaProg/main/resultado.png) Obs: os resultados foram iguais aos da aplicação em C++.
